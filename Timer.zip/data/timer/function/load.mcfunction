function timer:timer/load_time


tellraw @a [{"text":"[","color":"dark_gray"},{"text":"T","color":"#e66f00"},{"text":"i","color":"#e77c00"},{"text":"m","color":"#e98900"},{"text":"e","color":"#eb9600"},{"text":"r ","color":"#eca300"},{"text":"D","color":"#eeb000"},{"text":"a","color":"#f0be00"},{"text":"t","color":"#eeb000"},{"text":"a","color":"#eca300"},{"text":"p","color":"#ea9600"},{"text":"a","color":"#e88800"},{"text":"c","color":"#e67b00"},{"text":"k","color":"#e56e00"},{"text":"]","color":"dark_gray"},{"text":" Datapack has loaded","color":"dark_gray"}]
