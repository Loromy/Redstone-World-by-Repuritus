# Frame 1: Fokus auf Minuten-Zahl
execute if score wave timer_data matches 1..2 as @a[tag=show_timer] run title @s actionbar ["",{"score":{"name":"timer","objective":"playtime_tracker_min"},"color":"#9a0202"},{"text":"m ","color":"#b60101"},{"text":": ","color":"#d20000"},{"score":{"name":"timer","objective":"playtime_tracker_sec"},"color":"#ef0000"},{"text":"s","color":"#ef0000"}]

# Frame 2: Fokus auf "m"
execute if score wave timer_data matches 3..4 as @a[tag=show_timer] run title @s actionbar ["",{"score":{"name":"timer","objective":"playtime_tracker_min"},"color":"#b60101"},{"text":"m ","color":"#9a0202"},{"text":": ","color":"#b60101"},{"score":{"name":"timer","objective":"playtime_tracker_sec"},"color":"#d20000"},{"text":"s","color":"#ef0000"}]

# Frame 3: Fokus auf ":"
execute if score wave timer_data matches 5..6 as @a[tag=show_timer] run title @s actionbar ["",{"score":{"name":"timer","objective":"playtime_tracker_min"},"color":"#d20000"},{"text":"m ","color":"#b60101"},{"text":": ","color":"#9a0202"},{"score":{"name":"timer","objective":"playtime_tracker_sec"},"color":"#b60101"},{"text":"s","color":"#d20000"}]

# Frame 4: Fokus auf Sekunden-Zahl
execute if score wave timer_data matches 7..8 as @a[tag=show_timer] run title @s actionbar ["",{"score":{"name":"timer","objective":"playtime_tracker_min"},"color":"#ef0000"},{"text":"m ","color":"#d20000"},{"text":": ","color":"#b60101"},{"score":{"name":"timer","objective":"playtime_tracker_sec"},"color":"#9a0202"},{"text":"s","color":"#b60101"}]

# Frame 5: Fokus auf "s"
execute if score wave timer_data matches 9..10 as @a[tag=show_timer] run title @s actionbar ["",{"score":{"name":"timer","objective":"playtime_tracker_min"},"color":"#ef0000"},{"text":"m ","color":"#ef0000"},{"text":": ","color":"#d20000"},{"score":{"name":"timer","objective":"playtime_tracker_sec"},"color":"#b60101"},{"text":"s","color":"#9a0202"}]

# Frame 6: Neutral/Reset
execute if score wave timer_data matches 11..12 as @a[tag=show_timer] run title @s actionbar ["",{"score":{"name":"timer","objective":"playtime_tracker_min"},"color":"#ef0000"},{"text":"m ","color":"#ef0000"},{"text":": ","color":"#ef0000"},{"score":{"name":"timer","objective":"playtime_tracker_sec"},"color":"#ef0000"},{"text":"s","color":"#ef0000"}]