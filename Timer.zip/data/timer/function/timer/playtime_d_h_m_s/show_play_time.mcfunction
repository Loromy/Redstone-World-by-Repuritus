execute unless score timer playtime_tracker_min matches 1.. run execute unless score timer playtime_tracker_hour matches 1.. run execute unless score timer playtime_tracker_day matches 1.. run function timer:timer/playtime_d_h_m_s/show_play_time_s

execute if score timer playtime_tracker_min matches 1.. run execute unless score timer playtime_tracker_hour matches 1.. run execute unless score timer playtime_tracker_day matches 1.. run function timer:timer/playtime_d_h_m_s/show_play_time_m

execute if score timer playtime_tracker_min matches 1.. run execute if score timer playtime_tracker_hour matches 1.. run execute unless score timer playtime_tracker_day matches 1.. run function timer:timer/playtime_d_h_m_s/show_play_time_h

execute if score timer playtime_tracker_min matches 1.. run execute if score timer playtime_tracker_hour matches 1.. run execute if score timer playtime_tracker_day matches 1.. run function timer:timer/playtime_d_h_m_s/show_play_time_d
