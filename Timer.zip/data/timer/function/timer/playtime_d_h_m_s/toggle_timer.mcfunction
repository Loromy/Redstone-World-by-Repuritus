# 1. Wenn er das Tag hat, markiere ihn als "zum Löschen bereit"
tag @s[tag=show_timer] add remove_temp

# 2. Wenn er das Tag NICHT hat (und nicht gerade markiert wurde), füge es hinzu
tag @s[tag=!show_timer,tag=!remove_temp] add show_timer

# 3. Jetzt lösche das Tag bei denen, die wir in Schritt 1 markiert haben
tag @s[tag=remove_temp] remove show_timer

# 4. Aufräumen: Hilfs-Tag wieder weg
tag @s[tag=remove_temp] remove remove_temp

# Feedback für den Spieler
execute if entity @s[tag=show_timer] run tellraw @s {"text":"Timer: AN","color":"green"}
execute if entity @s[tag=!show_timer] run tellraw @s {"text":"Timer: AUS","color":"red"}