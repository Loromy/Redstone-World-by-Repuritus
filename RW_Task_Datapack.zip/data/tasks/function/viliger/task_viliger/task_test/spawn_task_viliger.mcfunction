summon villager ~ ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,CustomNameVisible:0b,NoAI:1b,CanPickUpLoot:0b,Tags:["rw_task_test"],CustomName:{"bold":true,"color":"dark_red","text":"Test"}}

summon interaction ~ ~ ~ {width:0.7f,height:2f,Tags:["rw_task_test","rw_task_test_interaction"]}
