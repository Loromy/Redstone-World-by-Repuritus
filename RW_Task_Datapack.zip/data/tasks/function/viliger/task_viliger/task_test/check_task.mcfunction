
execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute unless score @s task_test matches 0.. run tellraw @a ["",{"text":"[Task]:","bold":true,"color":"dark_red"},{"text":" test blabla"}]
execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute unless score @s task_test matches 0.. run scoreboard players set @s task_test 0

execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute if score @s task_test matches 1 run tellraw @a ["",{"text":"[Task]: ","bold":true,"color":"dark_red"},{"text":"test1"}]
execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute if score @s task_test matches 1 run scoreboard players set @s task_test 2

execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute if score @s task_test matches 3 run tellraw @a ["",{"text":"[Task]: ","bold":true,"color":"dark_red"},{"text":"test2"}]
execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute if score @s task_test matches 3 run scoreboard players set @s task_test 4

execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute if score @s task_test matches 5 run tellraw @a ["",{"text":"[Task]: ","bold":true,"color":"dark_red"},{"text":"test3"}]
execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute if score @s task_test matches 5 run scoreboard players set @s task_test 6

execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute if score @s task_test matches 7.. run tellraw @a ["",{"text":"[Task]: ","bold":true,"color":"dark_red"},{"text":"test4"}]
execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute if score @s task_test matches 7.. run scoreboard players set @s task_test 8






execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] on target at @s run execute if score @s task_test matches 0.. run scoreboard players add @s task_test 1


execute as @e[type=minecraft:interaction,tag=rw_task_test_interaction] run data remove entity @s interaction
