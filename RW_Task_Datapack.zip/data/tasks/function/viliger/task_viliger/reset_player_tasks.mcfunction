scoreboard players reset @s completed_quests_count

scoreboard players reset @s task_test
scoreboard players reset @s task_ores
scoreboard players reset @s task_forge

advancement revoke Repuritus from tasks:task/root
advancement grant Repuritus only tasks:task/root