scoreboard objectives add completed_quests_count dummy

scoreboard objectives add task_test dummy
scoreboard objectives add task_ores dummy
scoreboard objectives add task_forge dummy