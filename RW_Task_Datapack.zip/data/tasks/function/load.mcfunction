function tasks:viliger/load_viliger


tellraw @a [{"text":"[","color":"dark_gray"},{"text":"R","color":"#ff2323"},{"text":"W ","color":"#fd2032"},{"text":"T","color":"#fb1d41"},{"text":"a","color":"#f91a50"},{"text":"s","color":"#f8185f"},{"text":"k ","color":"#f6156f"},{"text":"D","color":"#f4127e"},{"text":"a","color":"#f3108d"},{"text":"t","color":"#f10d9c"},{"text":"a","color":"#ef0aac"},{"text":"p","color":"#ee08bb"},{"text":"a","color":"#ec05ca"},{"text":"c","color":"#ea02d9"},{"text":"k","color":"#e900e9"},{"text":"]","color":"dark_gray"},{"text":" Datapack has loaded","color":"dark_gray"}]


