function redstoneworld:time/tick_time

execute as @a at @s run function redstoneworld:player
function redstoneworld:custom_wapons/custom_wapon
function redstoneworld:hub/chest/hub_chest
function redstoneworld:ore_spawner/ore_spawner
function redstoneworld:clock/clock
function redstoneworld:red_station/space_suit/space_suit_fly_check
function redstoneworld:anti_gamemode_switch/check

execute if score show_board redstone_world_board matches 1 run function redstoneworld:server_scorboard/update
