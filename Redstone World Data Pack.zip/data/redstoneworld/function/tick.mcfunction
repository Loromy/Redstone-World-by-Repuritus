function redstoneworld:time/tick_time

execute as @a at @s run function redstoneworld:player
function redstoneworld:custom_wapons/custom_wapon
function redstoneworld:ore_spawner/ore_spawner
function redstoneworld:clock/clock
function redstoneworld:red_station/space_suit/space_suit_fly_check
function redstoneworld:anti_gamemode_switch/check
function redstoneworld:enderchest_inventar/chest/update
function redstoneworld:time/tick_time
function redstoneworld:timer/tick_time


function redstoneworld:tasks/viliger/tick_viliger

execute as @a[nbt={Dimension:"redstoneworld:dungeon"}] run function redstoneworld:mob_spawner/spawn/spawn_cooldown


execute if score show_board redstone_world_board matches 1 run function redstoneworld:server_scorboard/update

