scoreboard objectives add Redbytes dummy

#count
scoreboard objectives add RedbitCount dummy
scoreboard objectives add RedbyteCount dummy
scoreboard objectives add RedgigaCount dummy
scoreboard objectives add RedgigaBlockCount dummy