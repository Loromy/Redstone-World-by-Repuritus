function redstoneworld:time/load_time

function redstoneworld:mana/mana_load
function redstoneworld:custom_wapons/custom_wapon_load
function redstoneworld:clock/clock_load
function redstoneworld:red_station/space_suit/space_suit_fly_load
function redstoneworld:enderchest_inventar/chest/load


#function redstoneworld:tasks/viliger/load_viliger
#function redstoneworld:tasks/mob_spawner/spawn/load
#function redstoneworld:timer/load_time
function redstoneworld:tasks/viliger/load_viliger
function redstoneworld:mob_spawner/spawn/load


function redstoneworld:server_scorboard/load


tellraw @a [{"text":"[","color":"dark_gray"},{"text":"R","color":"#6f0000"},{"text":"e","color":"#7d0000"},{"text":"d","color":"#8b0000"},{"text":"s","color":"#9a0000"},{"text":"t","color":"#a80000"},{"text":"o","color":"#b70000"},{"text":"n","color":"#c50000"},{"text":"e ","color":"#d30000"},{"text":"W","color":"#e20000"},{"text":"o","color":"#f00000"},{"text":"r","color":"#ff0000"},{"text":"l","color":"#f10000"},{"text":"d ","color":"#e40000"},{"text":"D","color":"#d70000"},{"text":"a","color":"#ca0000"},{"text":"t","color":"#bd0000"},{"text":"a","color":"#af0000"},{"text":"p","color":"#a20000"},{"text":"a","color":"#950000"},{"text":"c","color":"#880000"},{"text":"k","color":"#7b0000"},{"text":"]","color":"dark_gray"},{"text":" Datapack has loaded","color":"dark_gray"}]
