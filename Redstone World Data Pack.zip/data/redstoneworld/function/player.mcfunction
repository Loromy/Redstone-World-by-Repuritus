function redstoneworld:mana/mana
function give:deko_items/show_item_frams
