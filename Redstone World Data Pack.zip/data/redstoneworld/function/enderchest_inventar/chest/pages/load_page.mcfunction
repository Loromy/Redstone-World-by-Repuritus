execute if score @s enderchest_page matches 0 run function redstoneworld:enderchest_inventar/chest/pages/enderchest_shop_home
execute if score @s enderchest_page matches 1 run function redstoneworld:enderchest_inventar/chest/pages/enderchest_shop_potions
execute if score @s enderchest_page matches 2 run function redstoneworld:enderchest_inventar/chest/pages/enderchest_shop_weapons
execute if score @s enderchest_page matches 3 run function redstoneworld:enderchest_inventar/chest/pages/enderchest_shop_armor
execute if score @s enderchest_page matches 4 run function redstoneworld:enderchest_inventar/chest/pages/enderchest_shop_train_tp

execute if score @s enderchest_page matches 6 run function redstoneworld:enderchest_inventar/chest/pages/enderchest_shop_food
execute if score @s enderchest_page matches 7 run function redstoneworld:enderchest_inventar/chest/pages/enderchest_shop_redbytes
execute if score @s enderchest_page matches 8 run function redstoneworld:enderchest_inventar/chest/pages/enderchest_shop_items
