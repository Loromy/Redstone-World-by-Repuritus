execute store result score @s hub_chest_item run data get entity @s Inventory[{components:{"minecraft:custom_data":{}}}].components.minecraft:custom_data.hub_chest

execute if score @s hub_chest_item matches 1 run execute unless score @s Redbytes matches 100.. run function redstoneworld:hub/chest/not_enough_redbyts_message
execute if score @s hub_chest_item matches 1 run execute if score @s Redbytes matches 100.. run function redstoneworld:redbytes/give_redgiga_block
execute if score @s hub_chest_item matches 1 run execute if score @s Redbytes matches 100.. run scoreboard players remove @s Redbytes 100

execute if score @s hub_chest_item matches 2 run execute unless score @s Redbytes matches 10.. run function redstoneworld:hub/chest/not_enough_redbyts_message
execute if score @s hub_chest_item matches 2 run execute if score @s Redbytes matches 10.. run function redstoneworld:redbytes/give_redgiga
execute if score @s hub_chest_item matches 2 run execute if score @s Redbytes matches 10.. run scoreboard players remove @s Redbytes 10

execute if score @s hub_chest_item matches 3 run execute unless score @s Redbytes matches 1.. run function redstoneworld:hub/chest/not_enough_redbyts_message
execute if score @s hub_chest_item matches 3 run execute if score @s Redbytes matches 1.. run function redstoneworld:redbytes/give_redbyte
execute if score @s hub_chest_item matches 3 run execute if score @s Redbytes matches 1.. run scoreboard players remove @s Redbytes 1

execute if score @s hub_chest_item matches 4 run execute unless score @s Redbytes matches 1.. run function redstoneworld:hub/chest/not_enough_redbyts_message
execute if score @s hub_chest_item matches 4 run execute if score @s Redbytes matches 1.. run function redstoneworld:redbytes/give_redbit
execute if score @s hub_chest_item matches 4 run execute if score @s Redbytes matches 1.. run scoreboard players remove @s Redbytes 1

execute if score @s hub_chest_item matches 9 run execute unless score @s Redbytes matches 1.. run function redstoneworld:hub/chest/not_enough_redbyts_message
execute if score @s hub_chest_item matches 9 run execute if score @s Redbytes matches 1.. run give @s golden_carrot 10
execute if score @s hub_chest_item matches 9 run execute if score @s Redbytes matches 1.. run scoreboard players remove @s Redbytes 1

execute if score @s hub_chest_item matches 10 run give @s minecraft:clock

execute if score @s hub_chest_item matches 14 run function give:item/redstone_book

execute if score @s hub_chest_item matches 18 run execute if entity @s[tag=OP] run function redstoneworld:give_operator_key_card
execute if score @s hub_chest_item matches 18 run execute unless entity @s[tag=OP] run tellraw @s [{"bold":true,"color":"dark_red","italic":false,"text":"[Redstone World]: "},{"bold":false,"color":"dark_gray","italic":false,"text":"You neet to be an Operator to get this Key-Card"}]

execute if score @s hub_chest_item matches 19 run execute unless score @s Redbytes matches 160.. run function redstoneworld:hub/chest/not_enough_redbyts_message
execute if score @s hub_chest_item matches 19 run execute if score @s Redbytes matches 160.. run function redstoneworld:mana/give_mana_potion
execute if score @s hub_chest_item matches 19 run execute if score @s Redbytes matches 160.. run scoreboard players remove @s Redbytes 160

execute if score @s hub_chest_item matches 27 run function redstoneworld:hub/stats/show_my_stats


execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:0}}}] run clear @s *[minecraft:custom_data={hub_chest:0}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:1}}}] run clear @s *[minecraft:custom_data={hub_chest:1}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:2}}}] run clear @s *[minecraft:custom_data={hub_chest:2}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:3}}}] run clear @s *[minecraft:custom_data={hub_chest:3}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:4}}}] run clear @s *[minecraft:custom_data={hub_chest:4}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:9}}}] run clear @s *[minecraft:custom_data={hub_chest:9}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:10}}}] run clear @s *[minecraft:custom_data={hub_chest:10}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:14}}}] run clear @s *[minecraft:custom_data={hub_chest:14}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:18}}}] run clear @s *[minecraft:custom_data={hub_chest:18}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:19}}}] run clear @s *[minecraft:custom_data={hub_chest:19}]
execute if data entity @s Inventory[{components:{"minecraft:custom_data":{hub_chest:27}}}] run clear @s *[minecraft:custom_data={hub_chest:27}]
