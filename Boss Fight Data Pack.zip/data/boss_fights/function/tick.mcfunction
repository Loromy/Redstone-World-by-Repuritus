#general-------------------------------------------------
function boss_fights:bosse/tick





execute as @a at @s run function boss_fights:player
