#bossbar
bossbar add magma_boss "The big Magmo"
bossbar set magma_boss color red
bossbar set magma_boss style progress
bossbar set magma_boss max 1000

#scorboards
scoreboard objectives add magma_boss_health dummy
scoreboard objectives add magma_boss_timer dummy
scoreboard objectives add magma_boss_lives dummy
scoreboard objectives add magma_boss_random_attack dummy
scoreboard objectives add player_magma_boss_kills dummy
