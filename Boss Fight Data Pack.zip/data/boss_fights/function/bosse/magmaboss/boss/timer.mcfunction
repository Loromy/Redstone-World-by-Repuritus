execute if score MagmaBoss magma_boss_lives matches 1 run scoreboard players add @s magma_boss_timer 1
execute if score @s magma_boss_timer matches 201.. run scoreboard players set @s magma_boss_timer 0
