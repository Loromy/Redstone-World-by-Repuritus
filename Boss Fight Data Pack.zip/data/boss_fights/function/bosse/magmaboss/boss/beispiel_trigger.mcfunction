execute as @e[type=marker,tag=magmaboss_spawn,distance=..20] at @s run execute if entity @a[distance=..50] run function boss_fights:bosse/magmaboss/boss/summon
