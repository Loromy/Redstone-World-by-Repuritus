scoreboard players set MagmaBoss magma_boss_lives 0
bossbar set minecraft:magma_boss players
execute as @e[type=minecraft:armor_stand,tag=magma_boss_armorstand] at @s run particle totem_of_undying ~ ~4 ~ 5 5 5 0.5 100 normal
execute as @e[type=minecraft:armor_stand,tag=magma_boss_armorstand] at @s run particle dust_color_transition{from_color:[1.000,0.000,0.000],to_color:[0.502,0.000,0.000],scale:2} ~ ~4 ~ 2 2 2 1 100 normal
execute as @e[type=minecraft:armor_stand,tag=magma_boss_armorstand] at @s run playsound ui.toast.challenge_complete master @a[distance=..50] ~ ~ ~ 1 1 1

#execute as @e[type=minecraft:armor_stand,tag=magma_boss_armorstand] at @s run advancement grant @a[distance=..50] only ...
execute as @e[type=minecraft:armor_stand,tag=magma_boss_armorstand] at @s run scoreboard players add @a[distance=..50] player_magma_boss_kills 1

kill @e[tag=magma_boss]
