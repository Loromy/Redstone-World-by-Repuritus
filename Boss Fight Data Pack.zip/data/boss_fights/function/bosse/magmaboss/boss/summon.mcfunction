summon magma_cube ~ ~ ~ {DeathLootTable:"boss_fights:dungeon/entities/magma_boss",Size:0,Tags:["magma_boss","magma_boss_boss"],attributes:[{id:"minecraft:attack_damage",base:7},{id:"minecraft:follow_range",base:20},{id:"minecraft:jump_strength",base:1},{id:"minecraft:max_health",base:1000},{id:"minecraft:movement_speed",base:0.4},{id:"minecraft:scale",base:10}]}
summon armor_stand ~ ~ ~ {Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["magma_boss","magma_boss_armorstand"]}



execute as @e[tag=magma_boss_boss] at @s run execute unless score MagmaBoss magma_boss_lives matches 1.. run scoreboard players set MagmaBoss magma_boss_lives 1
bossbar set magma_boss players @a[distance=..50]
execute as @e[tag=magma_boss_boss] at @s run execute unless score MagmaBoss magma_boss_lives matches 1.. run scoreboard players set MagmaBoss magma_boss_timer 0

playsound minecraft:custom.boss master @a[distance=..50] ~ ~ ~ 1 1 1
