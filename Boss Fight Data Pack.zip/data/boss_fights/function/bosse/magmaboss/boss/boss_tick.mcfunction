function boss_fights:bosse/magmaboss/boss/check_boss_health
function boss_fights:bosse/magmaboss/boss/timer


execute as @e[type=minecraft:armor_stand,tag=magma_boss_armorstand] at @s run teleport @s @e[limit=1,tag=magma_boss_boss]


#attaks
execute if score @s magma_boss_timer matches 200 run execute if entity @s[tag=!magma_boss_attack_2_minions] run execute store result score @s magma_boss_random_attack run random value 0..2



#1
execute as @e[distance=..50,type=armor_stand,tag=magma_boss_atack_1_armorstand] at @s run scoreboard players add @s magma_boss_random_attack 1
execute as @e[distance=..50,type=armor_stand,tag=magma_boss_atack_1_armorstand] at @s run execute if score @s magma_boss_random_attack matches 40 run kill @s

execute as @e[distance=..50,type=armor_stand,tag=magma_boss_atack_1_armorstand] at @s run particle dust_color_transition{from_color:[1.000,0.000,0.000],to_color:[0.502,0.000,0.000],scale:2} ^ ^0.2 ^3 0 0 0 0 10 normal
execute as @e[distance=..50,type=armor_stand,tag=magma_boss_atack_1_armorstand] at @s run particle dust_color_transition{from_color:[1.000,0.000,0.000],to_color:[0.502,0.000,0.000],scale:2} ^ ^0.2 ^-3 0 0 0 0 10 normal
execute as @e[distance=..50,type=armor_stand,tag=magma_boss_atack_1_armorstand] at @s run teleport @s ~ ~ ~ ~10 ~

execute if score @s magma_boss_timer matches 200 run execute if score @s magma_boss_random_attack matches 1 run function boss_fights:bosse/magmaboss/boss/attaks/slam_attack




#2
execute if entity @e[tag=magma_boss_mineon,distance=..50] run data merge entity @s {Invulnerable:1b}
execute unless entity @e[tag=magma_boss_mineon,distance=..50] run data merge entity @s {Invulnerable:0b}
execute unless entity @e[tag=magma_boss_mineon,distance=..50] run tag @s remove magma_boss_attack_2_minions


execute if score @s magma_boss_timer matches 200 run execute if score @s magma_boss_random_attack matches 2 run function boss_fights:bosse/magmaboss/boss/attaks/summon_mineons








scoreboard players set @s magma_boss_random_attack 0