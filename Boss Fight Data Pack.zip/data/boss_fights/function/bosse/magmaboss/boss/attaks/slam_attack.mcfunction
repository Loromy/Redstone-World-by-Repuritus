execute at @n[distance=..50,gamemode=!spectator,gamemode=!creative] run summon armor_stand ~ ~ ~ {Invulnerable:1b,Marker:1b,Invisible:1b,Tags:["magma_boss","magma_boss_atack_1_armorstand"]}

execute at @e[distance=..50,type=armor_stand,tag=magma_boss_atack_1_armorstand] run tp @s ~ ~20 ~
