execute if entity @s[tag=!magma_boss_attack_2_minions] run tag @s add magma_boss_attack_2_minions


execute positioned ~10 ~ ~ run summon blaze ~ ~ ~ {DeathLootTable:"boss_fights:dungeon/entities/blaze_minion",Tags:["magma_boss","magma_boss_mineon"],Glowing:1b}
execute positioned ~-10 ~ ~ run summon blaze ~ ~ ~ {DeathLootTable:"boss_fights:dungeon/entities/blaze_minion",Tags:["magma_boss","magma_boss_mineon"],Glowing:1b}
execute positioned ~ ~ ~10 run summon blaze ~ ~ ~ {DeathLootTable:"boss_fights:dungeon/entities/blaze_minion",Tags:["magma_boss","magma_boss_mineon"],Glowing:1b}
execute positioned ~ ~ ~-10 run summon blaze ~ ~ ~ {DeathLootTable:"boss_fights:dungeon/entities/blaze_minion",Tags:["magma_boss","magma_boss_mineon"],Glowing:1b}
