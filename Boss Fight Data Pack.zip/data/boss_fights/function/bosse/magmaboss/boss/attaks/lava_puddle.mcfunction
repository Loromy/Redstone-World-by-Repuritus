execute positioned ~10 ~ ~ run execute if block ~ ~ ~ minecraft:air run summon marker ~ ~ ~ {Tags:["magma_boss","magma_boss_lava"]}
execute positioned ~-10 ~ ~ run execute if block ~ ~ ~ minecraft:air run summon marker ~ ~ ~ {Tags:["magma_boss","magma_boss_lava"]}
execute positioned ~ ~ ~10 run execute if block ~ ~ ~ minecraft:air run summon marker ~ ~ ~ {Tags:["magma_boss","magma_boss_lava"]}
execute positioned ~ ~ ~-10 run execute if block ~ ~ ~ minecraft:air run summon marker ~ ~ ~ {Tags:["magma_boss","magma_boss_lava"]}

execute positioned ~10 ~ ~10 run execute if block ~ ~ ~ minecraft:air run summon marker ~ ~ ~ {Tags:["magma_boss","magma_boss_lava"]}
execute positioned ~-10 ~ ~-10 run execute if block ~ ~ ~ minecraft:air run summon marker ~ ~ ~ {Tags:["magma_boss","magma_boss_lava"]}
execute positioned ~-10 ~ ~10 run execute if block ~ ~ ~ minecraft:air run summon marker ~ ~ ~ {Tags:["magma_boss","magma_boss_lava"]}
execute positioned ~10 ~ ~-10 run execute if block ~ ~ ~ minecraft:air run summon marker ~ ~ ~ {Tags:["magma_boss","magma_boss_lava"]}


execute as @e[tag=magma_boss_lava] at @s run execute if block ~ ~ ~ air run setblock ~ ~ ~ minecraft:lava