#execute if score MagmaBoss magma_boss_lives matches 1 store result bossbar minecraft:magma_boss value run data get entity @e[tag=magma_boss_boss,limit=1] Health

execute if score MagmaBoss magma_boss_lives matches 1 store result score @s magma_boss_health run data get entity @e[tag=magma_boss_boss,limit=1] Health
execute if score MagmaBoss magma_boss_lives matches 1 store result bossbar minecraft:magma_boss value run scoreboard players get @s magma_boss_health
