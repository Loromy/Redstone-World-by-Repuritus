
#function boss_fights:bosse/magmaboss/boss/minions

execute if score MagmaBoss magma_boss_lives matches 1 unless entity @e[tag=magma_boss_boss] run function boss_fights:bosse/magmaboss/boss/death

execute as @e[tag=magma_boss_boss] at @s run execute if score MagmaBoss magma_boss_lives matches 1 run function boss_fights:bosse/magmaboss/boss/boss_tick
