function boss_fights:bosse/magmaboss/tick
