bossbar remove magma_boss

#scorboards
scoreboard objectives remove magma_boss_health
scoreboard objectives remove magma_boss_timer
scoreboard objectives remove magma_boss_lives
scoreboard objectives remove magma_boss_random_attack
scoreboard objectives remove player_magma_boss_kills


tellraw @a {"text":"[Redstone World] ", "color":"dark_red", "bold":true, "extra":[{"text":"Das Datapack wurde erfolgreich entfernt und alle zugehörigen Scoreboards wurden bereinigt.","color":"yellow","bold":false}]}
